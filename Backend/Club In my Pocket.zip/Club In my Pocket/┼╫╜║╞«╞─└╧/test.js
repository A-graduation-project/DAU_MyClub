// import mysql from "mysql2";
// const connection = mysql.createConnection({
//   host: "localhost",
//   user: "root",
//   database: "clubinpocket",
//   password: "tyt7539695",
// });

// connection.connect();

// connection.query("SELECT * from Users", (error, rows, fields) => {
//   if (error) throw error;
//   console.log("User info is: ", rows);
// });

// connection.end();
