import { db } from "../db/database.js";

export async function findByEmail(email) {
  return db
    .execute("SELECT * FROM users WHERE email=?", [email]) //
    .then((result) => result[0][0]);
}

export async function createUser(user) {
  return db
    .execute(
      "INSERT INTO users (id, department,email, password, username) VALUES (?,?,?,?,?)",
      [user.id, user.department, user.email, user.password, user.username]
    )
    .then((result) => {
      console.log(result);
      return result;
    });
}
